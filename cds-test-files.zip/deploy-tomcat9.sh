#!/bin/bash

Color_Off='\033[0m'       # Text Reset
# Regular Colors
Black='\033[0;30m'        # Black
Red='\033[0;31m'          # Red
Green='\033[0;32m'        # Green
Yellow='\033[0;33m'       # Yellow
Blue='\033[0;34m'         # Blue
Purple='\033[0;35m'       # Purple
Cyan='\033[0;36m'         # Cyan
White='\033[0;37m'        # White

printf "${Purple}\nMaking sure that s1-agents are in a READY state...${Color_Off}\n"
echo ""
S1_NAMESPACE=$(helm ls -A | grep s1-agent | cut -f 2)
if [ -z ${S1_NAMESPACE} ]; then
    printf "\n${Red}S1_NAMESPACE not discovered.  Please ensure s1-agents are deployed.\n${Color_Off}"
    exit 1
fi
  

printf "\n${Purple}Running: kubectl wait --for=condition=ready pod -n $S1_NAMESPACE -l app=s1-agent\n${Color_Off}"
kubectl wait --for=condition=ready pod -n $S1_NAMESPACE -l app=s1-agent

printf "\n${Purple}Sleeping 20 seconds...\n${Color_Off}"
sleep 20

printf "${Purple}\nDeploying JNDI...${Color_Off}\n"
echo ""

kubectl apply -f ./tomcat9-deploy.yaml
sleep 3

# output public IP address of VM
printf "${Purple}\nWaiting for Public Address to be assigned to the LoadBalancer${Color_Off}\n"
PUB_IP=""

# If EKS, need to get the hostname as opposed to an IP..
PROVIDER_ID=$(kubectl get nodes -o json | jq -r ".items[0].spec.providerID")
if [[ $PROVIDER_ID = aws* ]]; then
    while [ -z $PUB_IP ]; do 
        PUB_IP=$(kubectl get svc tomcat9-svc -ojson | jq -r ".status.loadBalancer.ingress[]?.hostname")
        [ -z "$PUB_IP" ]
        printf '.'
        sleep 5
    done
else
    while [ -z $PUB_IP ]; do 
        PUB_IP=$(kubectl get svc tomcat9-svc -ojson | jq -r ".status.loadBalancer.ingress[]?.ip")
        [ -z "$PUB_IP" ]
        printf '.'
        sleep 5
    done
fi

echo ""
printf "${Purple}\n"
#printf "PUBLIC ADDRESS:      $PUB_IP\n"
printf "JNDI URL:            http://${PUB_IP}${Color_Off}\n"

# Open a browser window to the JNDI URL...
printf "${Purple}\nWaiting for JNDI service to become available${Color_Off}\n"
until $(curl --output /dev/null --silent --head --fail http://${PUB_IP}); do
    printf "${White}."
    sleep 5
done

open http://${PUB_IP}

printf "\n${Purple}Done.${Color_Off}\n"




